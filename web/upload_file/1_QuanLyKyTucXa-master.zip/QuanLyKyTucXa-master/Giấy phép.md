﻿## Giấy phép của MIT (MIT)

MIT License (https://help.github.com/articles/licensing-a-repository/#disclaimer)

<ul>
	<li>Giấy phép MIT là một loại giấy phép sử dụng cho các phần mềm, các mã nguồn mở được phát triển dựa trên một loại giấy phép có nguồn gốc tại Viện Công nghệ Massachusetts (MIT).</li>
	<li>Giấy phép MIT là loại giấy phép cho phép sử dụng mã nguồn tự do nhất, nó có thể kết hợp 
	với các mã nguồn khác và đảm bảo tương thích tuân theo điều kiện của mọi lại giấy phép khác</li>
	<li>Giấy phép MIT còn có tên gọi khác là giấy phép X11, Giấy phép MIT đã được sử dụng nhiều cho các phần mềm cho các hệ thống X Window</li>
	
</ul>

<p align="center"><img src="http://static.congnghe.vn/tinmoi/store/techmag/thumb/21062016/215/them-cong-cu-stickies-ghi-chu-moi-tren-windows-10-2037549.jpg.600.0.jpg"></p>

<ul>
  <li>Giấy phép được cấp miễn phí cho bất kỳ người nào có được một bản sao của 
phần mềm này và các tài liệu liên quan để giải quyết những ấn đề liên quan đến phần mềm.</li>
  <li>Trong phần mềm không giới hạn, hay hạn chế quyền sử dụng sao chép, sủa một vài giao diện</li>
  <li>Hạn chế trong việc xuất bản, phân phối, cấp phép lại hoặc bán bản sao phần mềm</li>
  <li>TThông báo bản quyền ở trên và thông báo cho phép này sẽ được bao gồm trong tất cả các bản sao hoặc các phần đáng kể của Phần mềm</li>
  <li>Phần mềm được cung cấp đảm báo các yếu tố để phát triển phần mềm nhưng không bảo
đảm về các điều kiện để xuất bản, phân phối hay bán lại</li>
  <li>Phù hợp cho mục đích cụ thể và không vi phạm trong mọi trường hợp</li>
Tác giả Ngô Mậu Bảo, Nguyễn Thị Mỹ Linh và nhà cung cấp không chịu trách nhiệm đối với 
bất kì các khiếu nại hay thiệt hại khác
</ul>

<ul>
<li> Visual Studio 2013 (https://msdn.microsoft.com/en-us/library/dd831853(v=vs.120).aspx)</li>
<li> Visual Studio Community 2013 (https://www.visualstudio.com/en-us/news/releasenotes/vs2013-community-vs)</li>
<li> SQL Server 2012 (https://www.microsoft.com/en-us/download/details.aspx?id=29062)</li>
</ul>

**GOOD LUCK!!!**