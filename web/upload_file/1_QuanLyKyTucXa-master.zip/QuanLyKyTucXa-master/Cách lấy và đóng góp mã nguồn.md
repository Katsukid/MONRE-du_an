﻿![tuyen-ctv](https://user-images.githubusercontent.com/27652065/27720182-4c4f8a16-5d82-11e7-8bcf-ceb67903a130.png)


## CÁCH LẤY MÃ NGUỒN VÀ ĐÓNG GÓP MÃ NGUỒN



Phần mềm quản lý kí túc xá là đề tài nóng, luôn được cải tiến và làm mới. Nắm được những
vấn đề liên quan và thêm nhiều  suy nghĩ mới mẻ cho dự án. Nhằm nâng cao chất lượng quản lý,
tiết kiệm thời gian và không gian lưu trữ.

Qua bài viết và nội dung được tải lên, nếu các bạn muốn tham gia để đóng góp mã nguồn, giúp 
dự án thêm nhiều ưu điểm, hạn chế những sai sót, rủi ro.

## CÁCH LẤY MÃ

	Vào trang: 
<ul>
<li> Github:  (https://github.com/WebSiteQuanLy/QuanLyKyTucXa)</li>
</ul>


## CÁCH ĐÓNG GÓP MÃ NGUỒN

Sau khi lấy dữ liệu về (pull) máy tính các bạn lưu trữ ở 1 file rõ ràng. 
Đọc kĩ các giấy phép của dự án đã ghi, xem các quyền các bạn được sử dụng trong dự án.
Cài đặt các chương trình phần mềm hỗ trợ cho dự án.

Hoàn tất các bạn liên hệ gmail:
Ngomaubaodhcn1b@gmail.com
hoặc 01635286957

Trưởng team dự án sẽ thêm bạn vào thành viên hoặc cộng tác viên, để bạn có thể đóng
góp mã nguồn 1 cách nhanh chóng và hiệu quả.

## LINK THAM KHẢO

<ul>
<li> Visual Studio 2013 (https://msdn.microsoft.com/en-us/library/dd831853(v=vs.120).aspx)</li>
<li> Visual Studio Community 2013 (https://www.visualstudio.com/en-us/news/releasenotes/vs2013-community-vs)</li>
<li> SQL Server 2012 (https://www.microsoft.com/en-us/download/details.aspx?id=29062)</li>
</ul>

![tuyen-cong-tac-vien](https://user-images.githubusercontent.com/27652065/27718847-ca501c78-5d78-11e7-8e97-d8a028521e01.jpg)


 **!!!CẢM ƠN BẠN ĐÃ ĐỌC, MONG ĐƯỢC CỘNG TÁC!!!**