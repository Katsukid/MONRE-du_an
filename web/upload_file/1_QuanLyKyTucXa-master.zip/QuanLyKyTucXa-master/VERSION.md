﻿## Phiên bản Phần mềm "Quản lý kí túc xá sinh viên Khánh Hòa" 

** Hiện tại chỉ tồn tại một phiên bản này là phiên bản đầu tiên.**

** Bản quyền thuộc về Ngô Mậu Bảo & Nguyễn Thị Mỹ Linh **

Được cấp phép theo giấy phép của MIT, có trường học tái phân phối
thì phải được tải phân phối các tập tin nhưng phải dữ lại thông báo bản quyền ở trên.
