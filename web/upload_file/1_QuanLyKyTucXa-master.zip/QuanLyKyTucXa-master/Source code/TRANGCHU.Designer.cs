﻿namespace QLKTX
{
    partial class Trangchu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Trangchu));
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchPhòngHiệnCóToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hồSơSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiềnĐiệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.giớiThiệuVềKTXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.inDanhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.bang1tk = new System.Windows.Forms.GroupBox();
            this.bang2tk = new System.Windows.Forms.GroupBox();
            this.hitnthimaphongtk = new System.Windows.Forms.DataGridView();
            this.hienthimsvtk = new System.Windows.Forms.DataGridView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btnxoamptk = new System.Windows.Forms.Button();
            this.btnmptk = new System.Windows.Forms.Button();
            this.btnhthimptk = new System.Windows.Forms.Button();
            this.txtmptk = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btnxoasvtk = new System.Windows.Forms.Button();
            this.btnsvtk = new System.Windows.Forms.Button();
            this.btnhthimsvtk = new System.Windows.Forms.Button();
            this.txtmsvtk = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.h1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtmaphong = new System.Windows.Forms.TextBox();
            this.txtmakhu = new System.Windows.Forms.TextBox();
            this.txttenphong = new System.Windows.Forms.TextBox();
            this.txtsonguoihientai = new System.Windows.Forms.TextBox();
            this.txtsonguoitoida = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnhienthi = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnthem = new System.Windows.Forms.Button();
            this.Pnam = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bang1sv = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.bang2sv = new System.Windows.Forms.GroupBox();
            this.bang3sv = new System.Windows.Forms.GroupBox();
            this.dataGridViewsv = new System.Windows.Forms.DataGridView();
            this.btnhienthisv = new System.Windows.Forms.Button();
            this.btnsuasv = new System.Windows.Forms.Button();
            this.btnxoasv = new System.Windows.Forms.Button();
            this.btnthemsv = new System.Windows.Forms.Button();
            this.txthinh = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtnghenghiepsv = new System.Windows.Forms.TextBox();
            this.txtmoiquanhesv = new System.Windows.Forms.TextBox();
            this.txtsdtghsv = new System.Windows.Forms.TextBox();
            this.txttenghsv = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtngaysinhsv = new System.Windows.Forms.MaskedTextBox();
            this.txtmpsv = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.gtsv = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtquequansv = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtsdtsv = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtcmndsv = new System.Windows.Forms.TextBox();
            this.txttensv = new System.Windows.Forms.TextBox();
            this.txthosv = new System.Windows.Forms.TextBox();
            this.txtmaktxsv = new System.Windows.Forms.TextBox();
            this.txtmasvsv = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bangdiennuoc = new System.Windows.Forms.GroupBox();
            this.dataGridViewdiennuoc = new System.Windows.Forms.DataGridView();
            this.txtnuocmoidn = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txtdienmoidn = new System.Windows.Forms.TextBox();
            this.dateTimediennuoc = new System.Windows.Forms.DateTimePicker();
            this.label42 = new System.Windows.Forms.Label();
            this.txtnuoccudn = new System.Windows.Forms.TextBox();
            this.txtdiencudn = new System.Windows.Forms.TextBox();
            this.txtmaphongdn = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnlamlaidn = new System.Windows.Forms.Button();
            this.btnhienthidn = new System.Windows.Forms.Button();
            this.btnxoadn = new System.Windows.Forms.Button();
            this.btnsuadn = new System.Windows.Forms.Button();
            this.btnluudn = new System.Windows.Forms.Button();
            this.bangthongke = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.txtthongkephong = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtthongkesinhvien = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.inDanhSáchĐiệnNướcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.bang1tk.SuspendLayout();
            this.bang2tk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hitnthimaphongtk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hienthimsvtk)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.h1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.bang1sv.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.bang2sv.SuspendLayout();
            this.bang3sv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsv)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.bangdiennuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewdiennuoc)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.bangthongke.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhSáchPhòngHiệnCóToolStripMenuItem,
            this.thêmPhòngToolStripMenuItem});
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(133, 38);
            this.toolStripMenuItem1.Text = "Quản lý phòng ";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // danhSáchPhòngHiệnCóToolStripMenuItem
            // 
            this.danhSáchPhòngHiệnCóToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.danhSáchPhòngHiệnCóToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("danhSáchPhòngHiệnCóToolStripMenuItem.Image")));
            this.danhSáchPhòngHiệnCóToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.danhSáchPhòngHiệnCóToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.danhSáchPhòngHiệnCóToolStripMenuItem.Name = "danhSáchPhòngHiệnCóToolStripMenuItem";
            this.danhSáchPhòngHiệnCóToolStripMenuItem.Size = new System.Drawing.Size(228, 38);
            this.danhSáchPhòngHiệnCóToolStripMenuItem.Text = "Danh sách phòng hiện có ";
            this.danhSáchPhòngHiệnCóToolStripMenuItem.Click += new System.EventHandler(this.danhSáchPhòngHiệnCóToolStripMenuItem_Click);
            // 
            // thêmPhòngToolStripMenuItem
            // 
            this.thêmPhòngToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.thêmPhòngToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thêmPhòngToolStripMenuItem.Image")));
            this.thêmPhòngToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.thêmPhòngToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.thêmPhòngToolStripMenuItem.Name = "thêmPhòngToolStripMenuItem";
            this.thêmPhòngToolStripMenuItem.Size = new System.Drawing.Size(228, 38);
            this.thêmPhòngToolStripMenuItem.Text = "Thêm, Xóa, Sửa phòng";
            this.thêmPhòngToolStripMenuItem.Click += new System.EventHandler(this.thêmPhòngToolStripMenuItem_Click);
            // 
            // quảnLýSinhViênToolStripMenuItem
            // 
            this.quảnLýSinhViênToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.quảnLýSinhViênToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hồSơSinhViênToolStripMenuItem,
            this.thêmSinhViênToolStripMenuItem});
            this.quảnLýSinhViênToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýSinhViênToolStripMenuItem.Image")));
            this.quảnLýSinhViênToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.quảnLýSinhViênToolStripMenuItem.Name = "quảnLýSinhViênToolStripMenuItem";
            this.quảnLýSinhViênToolStripMenuItem.Size = new System.Drawing.Size(145, 38);
            this.quảnLýSinhViênToolStripMenuItem.Text = "Quản lý sinh viên ";
            this.quảnLýSinhViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýSinhViênToolStripMenuItem_Click);
            // 
            // hồSơSinhViênToolStripMenuItem
            // 
            this.hồSơSinhViênToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.hồSơSinhViênToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hồSơSinhViênToolStripMenuItem.Image")));
            this.hồSơSinhViênToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hồSơSinhViênToolStripMenuItem.Name = "hồSơSinhViênToolStripMenuItem";
            this.hồSơSinhViênToolStripMenuItem.Size = new System.Drawing.Size(228, 38);
            this.hồSơSinhViênToolStripMenuItem.Text = "Hồ sơ sinh viên ";
            this.hồSơSinhViênToolStripMenuItem.Click += new System.EventHandler(this.hồSơSinhViênToolStripMenuItem_Click);
            // 
            // thêmSinhViênToolStripMenuItem
            // 
            this.thêmSinhViênToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.thêmSinhViênToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thêmSinhViênToolStripMenuItem.Image")));
            this.thêmSinhViênToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.thêmSinhViênToolStripMenuItem.Name = "thêmSinhViênToolStripMenuItem";
            this.thêmSinhViênToolStripMenuItem.Size = new System.Drawing.Size(228, 38);
            this.thêmSinhViênToolStripMenuItem.Text = "Thêm, Xóa, Sửa  sinh viên ";
            this.thêmSinhViênToolStripMenuItem.Click += new System.EventHandler(this.thêmSinhViênToolStripMenuItem_Click);
            // 
            // hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem
            // 
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiềnĐiệnToolStripMenuItem,
            this.inDanhSáchĐiệnNướcToolStripMenuItem});
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.Image")));
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.Name = "hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem";
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.Size = new System.Drawing.Size(212, 38);
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.Text = "Hóa đơn điện nước điện nước ";
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem.Click += new System.EventHandler(this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem_Click);
            // 
            // tiềnĐiệnToolStripMenuItem
            // 
            this.tiềnĐiệnToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.tiềnĐiệnToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tiềnĐiệnToolStripMenuItem.Image")));
            this.tiềnĐiệnToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tiềnĐiệnToolStripMenuItem.Name = "tiềnĐiệnToolStripMenuItem";
            this.tiềnĐiệnToolStripMenuItem.Size = new System.Drawing.Size(209, 38);
            this.tiềnĐiệnToolStripMenuItem.Text = "Nhập chỉ số điện nước";
            this.tiềnĐiệnToolStripMenuItem.Click += new System.EventHandler(this.tiềnĐiệnToolStripMenuItem_Click);
            // 
            // tìmKiếmToolStripMenuItem
            // 
            this.tìmKiếmToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.tìmKiếmToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tìmKiếmToolStripMenuItem.Image")));
            this.tìmKiếmToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tìmKiếmToolStripMenuItem.Name = "tìmKiếmToolStripMenuItem";
            this.tìmKiếmToolStripMenuItem.Size = new System.Drawing.Size(104, 38);
            this.tìmKiếmToolStripMenuItem.Text = "Tìm kiếm ";
            this.tìmKiếmToolStripMenuItem.Click += new System.EventHandler(this.tìmKiếmToolStripMenuItem_Click);
            // 
            // tìmKiếmToolStripMenuItem1
            // 
            this.tìmKiếmToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.tìmKiếmToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("tìmKiếmToolStripMenuItem1.Image")));
            this.tìmKiếmToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tìmKiếmToolStripMenuItem1.Name = "tìmKiếmToolStripMenuItem1";
            this.tìmKiếmToolStripMenuItem1.Size = new System.Drawing.Size(151, 38);
            this.tìmKiếmToolStripMenuItem1.Text = "Tổng quan về KTX ";
            this.tìmKiếmToolStripMenuItem1.Click += new System.EventHandler(this.tìmKiếmToolStripMenuItem1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.quảnLýSinhViênToolStripMenuItem,
            this.hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem1,
            this.giớiThiệuVềKTXToolStripMenuItem,
            this.toolStripMenuItem2,
            this.inDanhSáchToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1250, 42);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menu";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // giớiThiệuVềKTXToolStripMenuItem
            // 
            this.giớiThiệuVềKTXToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("giớiThiệuVềKTXToolStripMenuItem.Image")));
            this.giớiThiệuVềKTXToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.giớiThiệuVềKTXToolStripMenuItem.Name = "giớiThiệuVềKTXToolStripMenuItem";
            this.giớiThiệuVềKTXToolStripMenuItem.Size = new System.Drawing.Size(141, 38);
            this.giớiThiệuVềKTXToolStripMenuItem.Text = "Giới thiệu về KTX";
            this.giớiThiệuVềKTXToolStripMenuItem.Click += new System.EventHandler(this.giớiThiệuVềKTXToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(12, 38);
            // 
            // inDanhSáchToolStripMenuItem
            // 
            this.inDanhSáchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("inDanhSáchToolStripMenuItem.Image")));
            this.inDanhSáchToolStripMenuItem.Name = "inDanhSáchToolStripMenuItem";
            this.inDanhSáchToolStripMenuItem.Size = new System.Drawing.Size(103, 38);
            this.inDanhSáchToolStripMenuItem.Text = "In Danh sách";
            this.inDanhSáchToolStripMenuItem.Click += new System.EventHandler(this.inDanhSáchToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(226, 51);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1012, 526);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(208, 121);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(84, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "14ĐC104";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Mã SV: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(84, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "ĐHCN1B";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Ngô Mậu Bảo";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Lớp : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Họ và tên :";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 98.60229F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 1.397713F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox13, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 45);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.06796F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.93204F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(220, 412);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label35);
            this.groupBox13.Controls.Add(this.label36);
            this.groupBox13.Controls.Add(this.label37);
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.label46);
            this.groupBox13.Controls.Add(this.label47);
            this.groupBox13.Location = new System.Drawing.Point(3, 130);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(208, 121);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Thông tin ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(84, 99);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(59, 13);
            this.label35.TabIndex = 5;
            this.label35.Text = "14ĐC199";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(10, 99);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(52, 13);
            this.label36.TabIndex = 4;
            this.label36.Text = "Mã SV: ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(84, 67);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(57, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "ĐHCN1B";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(84, 34);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 13);
            this.label45.TabIndex = 2;
            this.label45.Text = "Nguyễn Thị Mỹ Linh";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(10, 67);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(40, 13);
            this.label46.TabIndex = 1;
            this.label46.Text = "Lớp : ";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(10, 34);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(71, 13);
            this.label47.TabIndex = 0;
            this.label47.Text = "Họ và tên :";
            // 
            // bang1tk
            // 
            this.bang1tk.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang1tk.AutoSize = true;
            this.bang1tk.Controls.Add(this.bang2tk);
            this.bang1tk.Controls.Add(this.groupBox10);
            this.bang1tk.Controls.Add(this.groupBox11);
            this.bang1tk.Location = new System.Drawing.Point(224, 51);
            this.bang1tk.Name = "bang1tk";
            this.bang1tk.Size = new System.Drawing.Size(1026, 10725);
            this.bang1tk.TabIndex = 15;
            this.bang1tk.TabStop = false;
            this.bang1tk.Text = "Tìm kiếm ";
            // 
            // bang2tk
            // 
            this.bang2tk.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang2tk.AutoSize = true;
            this.bang2tk.Controls.Add(this.hitnthimaphongtk);
            this.bang2tk.Controls.Add(this.hienthimsvtk);
            this.bang2tk.Location = new System.Drawing.Point(0, 216);
            this.bang2tk.Name = "bang2tk";
            this.bang2tk.Size = new System.Drawing.Size(1764, 10339);
            this.bang2tk.TabIndex = 1;
            this.bang2tk.TabStop = false;
            this.bang2tk.Text = "Hiển thị ";
            // 
            // hitnthimaphongtk
            // 
            this.hitnthimaphongtk.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.hitnthimaphongtk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hitnthimaphongtk.Location = new System.Drawing.Point(497, 19);
            this.hitnthimaphongtk.Name = "hitnthimaphongtk";
            this.hitnthimaphongtk.Size = new System.Drawing.Size(445, 192);
            this.hitnthimaphongtk.TabIndex = 1;
            // 
            // hienthimsvtk
            // 
            this.hienthimsvtk.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.hienthimsvtk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hienthimsvtk.Location = new System.Drawing.Point(13, 19);
            this.hienthimsvtk.Name = "hienthimsvtk";
            this.hienthimsvtk.Size = new System.Drawing.Size(455, 192);
            this.hienthimsvtk.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btnxoamptk);
            this.groupBox10.Controls.Add(this.btnmptk);
            this.groupBox10.Controls.Add(this.btnhthimptk);
            this.groupBox10.Controls.Add(this.txtmptk);
            this.groupBox10.Controls.Add(this.label39);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox10.Location = new System.Drawing.Point(500, 25);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(413, 185);
            this.groupBox10.TabIndex = 3;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Tìm kiếm theo Mã phòng";
            // 
            // btnxoamptk
            // 
            this.btnxoamptk.Image = ((System.Drawing.Image)(resources.GetObject("btnxoamptk.Image")));
            this.btnxoamptk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnxoamptk.Location = new System.Drawing.Point(304, 103);
            this.btnxoamptk.Name = "btnxoamptk";
            this.btnxoamptk.Size = new System.Drawing.Size(98, 42);
            this.btnxoamptk.TabIndex = 3;
            this.btnxoamptk.Text = "LÀM MỚI";
            this.btnxoamptk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoamptk.UseVisualStyleBackColor = true;
            this.btnxoamptk.Click += new System.EventHandler(this.btnxoamptk_Click);
            // 
            // btnmptk
            // 
            this.btnmptk.Image = ((System.Drawing.Image)(resources.GetObject("btnmptk.Image")));
            this.btnmptk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnmptk.Location = new System.Drawing.Point(156, 102);
            this.btnmptk.Name = "btnmptk";
            this.btnmptk.Size = new System.Drawing.Size(123, 42);
            this.btnmptk.TabIndex = 5;
            this.btnmptk.Text = "TÌM KIẾM ";
            this.btnmptk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnmptk.UseVisualStyleBackColor = true;
            this.btnmptk.Click += new System.EventHandler(this.btnmptk_Click);
            // 
            // btnhthimptk
            // 
            this.btnhthimptk.Image = ((System.Drawing.Image)(resources.GetObject("btnhthimptk.Image")));
            this.btnhthimptk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnhthimptk.Location = new System.Drawing.Point(9, 100);
            this.btnhthimptk.Name = "btnhthimptk";
            this.btnhthimptk.Size = new System.Drawing.Size(114, 42);
            this.btnhthimptk.TabIndex = 4;
            this.btnhthimptk.Text = "HIỂN THỊ";
            this.btnhthimptk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhthimptk.UseVisualStyleBackColor = true;
            this.btnhthimptk.Click += new System.EventHandler(this.btnhthimptk_Click);
            // 
            // txtmptk
            // 
            this.txtmptk.Location = new System.Drawing.Point(131, 34);
            this.txtmptk.Name = "txtmptk";
            this.txtmptk.Size = new System.Drawing.Size(271, 22);
            this.txtmptk.TabIndex = 1;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 37);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(125, 16);
            this.label39.TabIndex = 0;
            this.label39.Text = "Nhập Mã phòng :";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnxoasvtk);
            this.groupBox11.Controls.Add(this.btnsvtk);
            this.groupBox11.Controls.Add(this.btnhthimsvtk);
            this.groupBox11.Controls.Add(this.txtmsvtk);
            this.groupBox11.Controls.Add(this.label38);
            this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox11.Location = new System.Drawing.Point(51, 24);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(417, 184);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Tìm kiếm theo Mã Sinh viên";
            // 
            // btnxoasvtk
            // 
            this.btnxoasvtk.Image = ((System.Drawing.Image)(resources.GetObject("btnxoasvtk.Image")));
            this.btnxoasvtk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnxoasvtk.Location = new System.Drawing.Point(296, 104);
            this.btnxoasvtk.Name = "btnxoasvtk";
            this.btnxoasvtk.Size = new System.Drawing.Size(102, 41);
            this.btnxoasvtk.TabIndex = 4;
            this.btnxoasvtk.Text = "LÀM MỚI ";
            this.btnxoasvtk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoasvtk.UseVisualStyleBackColor = true;
            this.btnxoasvtk.Click += new System.EventHandler(this.btnxoasvtk_Click);
            // 
            // btnsvtk
            // 
            this.btnsvtk.Image = ((System.Drawing.Image)(resources.GetObject("btnsvtk.Image")));
            this.btnsvtk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsvtk.Location = new System.Drawing.Point(143, 104);
            this.btnsvtk.Name = "btnsvtk";
            this.btnsvtk.Size = new System.Drawing.Size(122, 41);
            this.btnsvtk.TabIndex = 3;
            this.btnsvtk.Text = "TÌM KIẾM ";
            this.btnsvtk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsvtk.UseVisualStyleBackColor = true;
            this.btnsvtk.Click += new System.EventHandler(this.btnsvtk_Click);
            // 
            // btnhthimsvtk
            // 
            this.btnhthimsvtk.Image = ((System.Drawing.Image)(resources.GetObject("btnhthimsvtk.Image")));
            this.btnhthimsvtk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnhthimsvtk.Location = new System.Drawing.Point(6, 101);
            this.btnhthimsvtk.Name = "btnhthimsvtk";
            this.btnhthimsvtk.Size = new System.Drawing.Size(114, 41);
            this.btnhthimsvtk.TabIndex = 2;
            this.btnhthimsvtk.Text = "HIỂN THỊ ";
            this.btnhthimsvtk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhthimsvtk.UseVisualStyleBackColor = true;
            this.btnhthimsvtk.Click += new System.EventHandler(this.btnhthimsvtk_Click);
            // 
            // txtmsvtk
            // 
            this.txtmsvtk.Location = new System.Drawing.Point(114, 34);
            this.txtmsvtk.Name = "txtmsvtk";
            this.txtmsvtk.Size = new System.Drawing.Size(269, 22);
            this.txtmsvtk.TabIndex = 1;
            this.txtmsvtk.TextChanged += new System.EventHandler(this.txtmsvtk_TextChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 37);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(102, 16);
            this.label38.TabIndex = 0;
            this.label38.Text = "Nhập mã SV :";
            // 
            // h1
            // 
            this.h1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.h1.Image = ((System.Drawing.Image)(resources.GetObject("h1.Image")));
            this.h1.Location = new System.Drawing.Point(226, 51);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(1200, 723);
            this.h1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.h1.TabIndex = 3;
            this.h1.TabStop = false;
            this.h1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.AutoSize = true;
            this.groupBox4.Controls.Add(this.dataGridView2);
            this.groupBox4.Location = new System.Drawing.Point(6, 237);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1180, 65483);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 19);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1154, 58647);
            this.dataGridView2.TabIndex = 4;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(300, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "THÊM, XÓA, SỬA PHÒNG";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "MÃ PHÒNG :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(397, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "SỐ NGƯỜI HIỆN TẠI :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(59, 92);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "MÃ KHU :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(409, 137);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "SỐ NGƯỜI TỐI ĐA :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(34, 134);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "TÊN PHÒNG :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(440, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "LOẠI PHÒNG :";
            // 
            // txtmaphong
            // 
            this.txtmaphong.Location = new System.Drawing.Point(149, 49);
            this.txtmaphong.Name = "txtmaphong";
            this.txtmaphong.Size = new System.Drawing.Size(183, 20);
            this.txtmaphong.TabIndex = 5;
            // 
            // txtmakhu
            // 
            this.txtmakhu.Location = new System.Drawing.Point(149, 89);
            this.txtmakhu.Name = "txtmakhu";
            this.txtmakhu.Size = new System.Drawing.Size(183, 20);
            this.txtmakhu.TabIndex = 6;
            // 
            // txttenphong
            // 
            this.txttenphong.Location = new System.Drawing.Point(149, 130);
            this.txttenphong.Name = "txttenphong";
            this.txttenphong.Size = new System.Drawing.Size(183, 20);
            this.txttenphong.TabIndex = 7;
            this.txttenphong.TextChanged += new System.EventHandler(this.txttenphong_TextChanged);
            // 
            // txtsonguoihientai
            // 
            this.txtsonguoihientai.Location = new System.Drawing.Point(563, 90);
            this.txtsonguoihientai.Name = "txtsonguoihientai";
            this.txtsonguoihientai.Size = new System.Drawing.Size(184, 20);
            this.txtsonguoihientai.TabIndex = 9;
            // 
            // txtsonguoitoida
            // 
            this.txtsonguoitoida.Location = new System.Drawing.Point(563, 130);
            this.txtsonguoitoida.Name = "txtsonguoitoida";
            this.txtsonguoitoida.Size = new System.Drawing.Size(184, 20);
            this.txtsonguoitoida.TabIndex = 10;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.AutoSize = true;
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.groupBox3.Controls.Add(this.btnhienthi);
            this.groupBox3.Controls.Add(this.btnsua);
            this.groupBox3.Controls.Add(this.btnxoa);
            this.groupBox3.Controls.Add(this.btnthem);
            this.groupBox3.Location = new System.Drawing.Point(27, 177);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1036, 65535);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btnhienthi
            // 
            this.btnhienthi.Image = ((System.Drawing.Image)(resources.GetObject("btnhienthi.Image")));
            this.btnhienthi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnhienthi.Location = new System.Drawing.Point(600, 19);
            this.btnhienthi.Name = "btnhienthi";
            this.btnhienthi.Size = new System.Drawing.Size(114, 35);
            this.btnhienthi.TabIndex = 5;
            this.btnhienthi.Text = "HIỂN THỊ ";
            this.btnhienthi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhienthi.UseVisualStyleBackColor = true;
            this.btnhienthi.Click += new System.EventHandler(this.btnhienthi_Click);
            // 
            // btnsua
            // 
            this.btnsua.Image = ((System.Drawing.Image)(resources.GetObject("btnsua.Image")));
            this.btnsua.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnsua.Location = new System.Drawing.Point(424, 19);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(107, 35);
            this.btnsua.TabIndex = 4;
            this.btnsua.Text = "SỬA";
            this.btnsua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsua.UseVisualStyleBackColor = true;
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Image = ((System.Drawing.Image)(resources.GetObject("btnxoa.Image")));
            this.btnxoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnxoa.Location = new System.Drawing.Point(256, 19);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(96, 35);
            this.btnxoa.TabIndex = 3;
            this.btnxoa.Text = "XÓA";
            this.btnxoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnthem
            // 
            this.btnthem.Image = ((System.Drawing.Image)(resources.GetObject("btnthem.Image")));
            this.btnthem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnthem.Location = new System.Drawing.Point(91, 19);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(99, 35);
            this.btnthem.TabIndex = 0;
            this.btnthem.Text = "THÊM ";
            this.btnthem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // Pnam
            // 
            this.Pnam.AutoSize = true;
            this.Pnam.Location = new System.Drawing.Point(563, 55);
            this.Pnam.Name = "Pnam";
            this.Pnam.Size = new System.Drawing.Size(91, 17);
            this.Pnam.TabIndex = 11;
            this.Pnam.Text = "Phòng Nam";
            this.Pnam.UseVisualStyleBackColor = true;
            this.Pnam.CheckedChanged += new System.EventHandler(this.Pnam_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.Pnam);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.txtsonguoitoida);
            this.groupBox1.Controls.Add(this.txtsonguoihientai);
            this.groupBox1.Controls.Add(this.txttenphong);
            this.groupBox1.Controls.Add(this.txtmakhu);
            this.groupBox1.Controls.Add(this.txtmaphong);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(226, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1867, 65535);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // bang1sv
            // 
            this.bang1sv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang1sv.AutoSize = true;
            this.bang1sv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bang1sv.Controls.Add(this.groupBox6);
            this.bang1sv.Controls.Add(this.bang2sv);
            this.bang1sv.Controls.Add(this.txthinh);
            this.bang1sv.Controls.Add(this.groupBox8);
            this.bang1sv.Controls.Add(this.groupBox5);
            this.bang1sv.Controls.Add(this.label9);
            this.bang1sv.Location = new System.Drawing.Point(226, 48);
            this.bang1sv.Name = "bang1sv";
            this.bang1sv.Size = new System.Drawing.Size(1733, 3491);
            this.bang1sv.TabIndex = 15;
            this.bang1sv.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.AutoSize = true;
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.groupBox6.Controls.Add(this.dataGridView3);
            this.groupBox6.Location = new System.Drawing.Point(6, 347);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1727, 2369);
            this.groupBox6.TabIndex = 17;
            this.groupBox6.TabStop = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(6, 15);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1715, 2239);
            this.dataGridView3.TabIndex = 1;
            // 
            // bang2sv
            // 
            this.bang2sv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang2sv.AutoSize = true;
            this.bang2sv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bang2sv.Controls.Add(this.bang3sv);
            this.bang2sv.Controls.Add(this.btnhienthisv);
            this.bang2sv.Controls.Add(this.btnsuasv);
            this.bang2sv.Controls.Add(this.btnxoasv);
            this.bang2sv.Controls.Add(this.btnthemsv);
            this.bang2sv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bang2sv.Location = new System.Drawing.Point(6, 274);
            this.bang2sv.Name = "bang2sv";
            this.bang2sv.Size = new System.Drawing.Size(2016, 4599);
            this.bang2sv.TabIndex = 16;
            this.bang2sv.TabStop = false;
            // 
            // bang3sv
            // 
            this.bang3sv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang3sv.AutoSize = true;
            this.bang3sv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bang3sv.Controls.Add(this.dataGridViewsv);
            this.bang3sv.Location = new System.Drawing.Point(30, 1177);
            this.bang3sv.Name = "bang3sv";
            this.bang3sv.Size = new System.Drawing.Size(1959, 2245);
            this.bang3sv.TabIndex = 17;
            this.bang3sv.TabStop = false;
            // 
            // dataGridViewsv
            // 
            this.dataGridViewsv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewsv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridViewsv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewsv.Location = new System.Drawing.Point(0, 19);
            this.dataGridViewsv.Name = "dataGridViewsv";
            this.dataGridViewsv.Size = new System.Drawing.Size(1953, 2201);
            this.dataGridViewsv.TabIndex = 1;
            // 
            // btnhienthisv
            // 
            this.btnhienthisv.Image = ((System.Drawing.Image)(resources.GetObject("btnhienthisv.Image")));
            this.btnhienthisv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnhienthisv.Location = new System.Drawing.Point(669, 9);
            this.btnhienthisv.Name = "btnhienthisv";
            this.btnhienthisv.Size = new System.Drawing.Size(100, 43);
            this.btnhienthisv.TabIndex = 3;
            this.btnhienthisv.Text = "HIỂN THỊ";
            this.btnhienthisv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhienthisv.UseVisualStyleBackColor = true;
            this.btnhienthisv.Click += new System.EventHandler(this.btnhienthisv_Click_2);
            // 
            // btnsuasv
            // 
            this.btnsuasv.Image = ((System.Drawing.Image)(resources.GetObject("btnsuasv.Image")));
            this.btnsuasv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsuasv.Location = new System.Drawing.Point(497, 9);
            this.btnsuasv.Name = "btnsuasv";
            this.btnsuasv.Size = new System.Drawing.Size(99, 43);
            this.btnsuasv.TabIndex = 2;
            this.btnsuasv.Text = "SỬA";
            this.btnsuasv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuasv.UseVisualStyleBackColor = true;
            this.btnsuasv.Click += new System.EventHandler(this.btnsuasv_Click_2);
            // 
            // btnxoasv
            // 
            this.btnxoasv.Image = ((System.Drawing.Image)(resources.GetObject("btnxoasv.Image")));
            this.btnxoasv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnxoasv.Location = new System.Drawing.Point(287, 9);
            this.btnxoasv.Name = "btnxoasv";
            this.btnxoasv.Size = new System.Drawing.Size(84, 43);
            this.btnxoasv.TabIndex = 1;
            this.btnxoasv.Text = "XÓA";
            this.btnxoasv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoasv.UseVisualStyleBackColor = true;
            this.btnxoasv.Click += new System.EventHandler(this.btnxoasv_Click_1);
            // 
            // btnthemsv
            // 
            this.btnthemsv.Image = ((System.Drawing.Image)(resources.GetObject("btnthemsv.Image")));
            this.btnthemsv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnthemsv.Location = new System.Drawing.Point(116, 9);
            this.btnthemsv.Name = "btnthemsv";
            this.btnthemsv.Size = new System.Drawing.Size(88, 43);
            this.btnthemsv.TabIndex = 0;
            this.btnthemsv.Text = "THÊM";
            this.btnthemsv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthemsv.UseVisualStyleBackColor = true;
            this.btnthemsv.Click += new System.EventHandler(this.btnthemsv_Click_1);
            // 
            // txthinh
            // 
            this.txthinh.Location = new System.Drawing.Point(817, 122);
            this.txthinh.Name = "txthinh";
            this.txthinh.Size = new System.Drawing.Size(100, 20);
            this.txthinh.TabIndex = 4;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtnghenghiepsv);
            this.groupBox8.Controls.Add(this.txtmoiquanhesv);
            this.groupBox8.Controls.Add(this.txtsdtghsv);
            this.groupBox8.Controls.Add(this.txttenghsv);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Location = new System.Drawing.Point(575, 46);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 222);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Thông tin người giám hộ ";
            // 
            // txtnghenghiepsv
            // 
            this.txtnghenghiepsv.Location = new System.Drawing.Point(94, 167);
            this.txtnghenghiepsv.Name = "txtnghenghiepsv";
            this.txtnghenghiepsv.Size = new System.Drawing.Size(100, 20);
            this.txtnghenghiepsv.TabIndex = 29;
            // 
            // txtmoiquanhesv
            // 
            this.txtmoiquanhesv.Location = new System.Drawing.Point(94, 122);
            this.txtmoiquanhesv.Name = "txtmoiquanhesv";
            this.txtmoiquanhesv.Size = new System.Drawing.Size(100, 20);
            this.txtmoiquanhesv.TabIndex = 28;
            // 
            // txtsdtghsv
            // 
            this.txtsdtghsv.Location = new System.Drawing.Point(94, 77);
            this.txtsdtghsv.Name = "txtsdtghsv";
            this.txtsdtghsv.Size = new System.Drawing.Size(100, 20);
            this.txtsdtghsv.TabIndex = 27;
            // 
            // txttenghsv
            // 
            this.txttenghsv.Location = new System.Drawing.Point(94, 27);
            this.txttenghsv.Name = "txttenghsv";
            this.txttenghsv.Size = new System.Drawing.Size(100, 20);
            this.txttenghsv.TabIndex = 23;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1, 170);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(87, 13);
            this.label30.TabIndex = 26;
            this.label30.Text = "Nghề nghiệp :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 125);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(85, 13);
            this.label29.TabIndex = 25;
            this.label29.Text = "Mối quan hệ :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 81);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(82, 13);
            this.label28.TabIndex = 24;
            this.label28.Text = "Số ĐT NGH :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(4, 30);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(84, 13);
            this.label27.TabIndex = 23;
            this.label27.Text = "Họ tên NGH :";
            // 
            // groupBox5
            // 
            this.groupBox5.AutoSize = true;
            this.groupBox5.Controls.Add(this.txtngaysinhsv);
            this.groupBox5.Controls.Add(this.txtmpsv);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.dateTimePicker1);
            this.groupBox5.Controls.Add(this.gtsv);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.txtquequansv);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.txtsdtsv);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.txtcmndsv);
            this.groupBox5.Controls.Add(this.txttensv);
            this.groupBox5.Controls.Add(this.txthosv);
            this.groupBox5.Controls.Add(this.txtmaktxsv);
            this.groupBox5.Controls.Add(this.txtmasvsv);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Location = new System.Drawing.Point(109, 46);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(399, 225);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thông tin sinh viên";
            // 
            // txtngaysinhsv
            // 
            this.txtngaysinhsv.Location = new System.Drawing.Point(85, 122);
            this.txtngaysinhsv.Mask = "00/00/0000";
            this.txtngaysinhsv.Name = "txtngaysinhsv";
            this.txtngaysinhsv.Size = new System.Drawing.Size(100, 20);
            this.txtngaysinhsv.TabIndex = 4;
            this.txtngaysinhsv.ValidatingType = typeof(System.DateTime);
            // 
            // txtmpsv
            // 
            this.txtmpsv.Location = new System.Drawing.Point(85, 154);
            this.txtmpsv.Name = "txtmpsv";
            this.txtmpsv.Size = new System.Drawing.Size(100, 20);
            this.txtmpsv.TabIndex = 23;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(4, 157);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(75, 13);
            this.label26.TabIndex = 21;
            this.label26.Text = "Mã phòng : ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(133, 186);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 20;
            // 
            // gtsv
            // 
            this.gtsv.AutoSize = true;
            this.gtsv.Location = new System.Drawing.Point(285, 124);
            this.gtsv.Name = "gtsv";
            this.gtsv.Size = new System.Drawing.Size(55, 17);
            this.gtsv.TabIndex = 19;
            this.gtsv.Text = "Nam ";
            this.gtsv.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(205, 125);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(68, 13);
            this.label25.TabIndex = 18;
            this.label25.Text = "Giới tính : ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(2, 192);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(125, 13);
            this.label24.TabIndex = 17;
            this.label24.Text = "Ngày làm hợp đồng :";
            // 
            // txtquequansv
            // 
            this.txtquequansv.Location = new System.Drawing.Point(285, 154);
            this.txtquequansv.Name = "txtquequansv";
            this.txtquequansv.Size = new System.Drawing.Size(100, 20);
            this.txtquequansv.TabIndex = 16;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(203, 160);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 13);
            this.label23.TabIndex = 15;
            this.label23.Text = "Quê quán :";
            // 
            // txtsdtsv
            // 
            this.txtsdtsv.Location = new System.Drawing.Point(285, 84);
            this.txtsdtsv.Name = "txtsdtsv";
            this.txtsdtsv.Size = new System.Drawing.Size(100, 20);
            this.txtsdtsv.TabIndex = 14;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(211, 90);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 13);
            this.label22.TabIndex = 12;
            this.label22.Text = "Số ĐT :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 125);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 13);
            this.label21.TabIndex = 11;
            this.label21.Text = "Ngày sinh :";
            // 
            // txtcmndsv
            // 
            this.txtcmndsv.Location = new System.Drawing.Point(85, 84);
            this.txtcmndsv.Name = "txtcmndsv";
            this.txtcmndsv.Size = new System.Drawing.Size(100, 20);
            this.txtcmndsv.TabIndex = 10;
            // 
            // txttensv
            // 
            this.txttensv.Location = new System.Drawing.Point(285, 51);
            this.txttensv.Name = "txttensv";
            this.txttensv.Size = new System.Drawing.Size(100, 20);
            this.txttensv.TabIndex = 9;
            // 
            // txthosv
            // 
            this.txthosv.Location = new System.Drawing.Point(285, 19);
            this.txthosv.Name = "txthosv";
            this.txthosv.Size = new System.Drawing.Size(100, 20);
            this.txthosv.TabIndex = 8;
            // 
            // txtmaktxsv
            // 
            this.txtmaktxsv.Location = new System.Drawing.Point(85, 55);
            this.txtmaktxsv.Name = "txtmaktxsv";
            this.txtmaktxsv.Size = new System.Drawing.Size(100, 20);
            this.txtmaktxsv.TabIndex = 7;
            // 
            // txtmasvsv
            // 
            this.txtmasvsv.Location = new System.Drawing.Point(85, 22);
            this.txtmasvsv.Name = "txtmasvsv";
            this.txtmasvsv.Size = new System.Drawing.Size(100, 20);
            this.txtmasvsv.TabIndex = 6;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(205, 83);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(0, 13);
            this.label20.TabIndex = 5;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(22, 90);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "CMND : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(205, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Tên SV :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(211, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 13);
            this.label17.TabIndex = 2;
            this.label17.Text = "Họ SV :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 58);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Mã KTX :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Mã SV :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(409, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(233, 18);
            this.label9.TabIndex = 1;
            this.label9.Text = "THÊM, XÓA, SỬA SINH VIÊN ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bangdiennuoc
            // 
            this.bangdiennuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bangdiennuoc.AutoSize = true;
            this.bangdiennuoc.Controls.Add(this.dataGridViewdiennuoc);
            this.bangdiennuoc.Controls.Add(this.txtnuocmoidn);
            this.bangdiennuoc.Controls.Add(this.label44);
            this.bangdiennuoc.Controls.Add(this.label43);
            this.bangdiennuoc.Controls.Add(this.txtdienmoidn);
            this.bangdiennuoc.Controls.Add(this.dateTimediennuoc);
            this.bangdiennuoc.Controls.Add(this.label42);
            this.bangdiennuoc.Controls.Add(this.txtnuoccudn);
            this.bangdiennuoc.Controls.Add(this.txtdiencudn);
            this.bangdiennuoc.Controls.Add(this.txtmaphongdn);
            this.bangdiennuoc.Controls.Add(this.label41);
            this.bangdiennuoc.Controls.Add(this.label40);
            this.bangdiennuoc.Controls.Add(this.label32);
            this.bangdiennuoc.Controls.Add(this.label31);
            this.bangdiennuoc.Controls.Add(this.groupBox7);
            this.bangdiennuoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bangdiennuoc.Location = new System.Drawing.Point(226, 45);
            this.bangdiennuoc.Name = "bangdiennuoc";
            this.bangdiennuoc.Size = new System.Drawing.Size(1024, 549);
            this.bangdiennuoc.TabIndex = 5;
            this.bangdiennuoc.TabStop = false;
            this.bangdiennuoc.Text = "Nhập chỉ số điện nước";
            // 
            // dataGridViewdiennuoc
            // 
            this.dataGridViewdiennuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewdiennuoc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridViewdiennuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewdiennuoc.Location = new System.Drawing.Point(12, 335);
            this.dataGridViewdiennuoc.Name = "dataGridViewdiennuoc";
            this.dataGridViewdiennuoc.Size = new System.Drawing.Size(1000, 208);
            this.dataGridViewdiennuoc.TabIndex = 19;
            // 
            // txtnuocmoidn
            // 
            this.txtnuocmoidn.Location = new System.Drawing.Point(584, 177);
            this.txtnuocmoidn.Name = "txtnuocmoidn";
            this.txtnuocmoidn.Size = new System.Drawing.Size(200, 22);
            this.txtnuocmoidn.TabIndex = 18;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(427, 176);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(125, 16);
            this.label44.TabIndex = 17;
            this.label44.Text = "Chỉ số nước mới :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(430, 118);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(122, 16);
            this.label43.TabIndex = 16;
            this.label43.Text = "Chỉ số điện mới :";
            // 
            // txtdienmoidn
            // 
            this.txtdienmoidn.Location = new System.Drawing.Point(584, 118);
            this.txtdienmoidn.Name = "txtdienmoidn";
            this.txtdienmoidn.Size = new System.Drawing.Size(200, 22);
            this.txtdienmoidn.TabIndex = 15;
            // 
            // dateTimediennuoc
            // 
            this.dateTimediennuoc.Location = new System.Drawing.Point(579, 53);
            this.dateTimediennuoc.Name = "dateTimediennuoc";
            this.dateTimediennuoc.Size = new System.Drawing.Size(200, 22);
            this.dateTimediennuoc.TabIndex = 14;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(492, 55);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(60, 16);
            this.label42.TabIndex = 9;
            this.label42.Text = "Tháng :";
            // 
            // txtnuoccudn
            // 
            this.txtnuoccudn.Location = new System.Drawing.Point(189, 177);
            this.txtnuoccudn.Name = "txtnuoccudn";
            this.txtnuoccudn.Size = new System.Drawing.Size(166, 22);
            this.txtnuoccudn.TabIndex = 8;
            // 
            // txtdiencudn
            // 
            this.txtdiencudn.Location = new System.Drawing.Point(189, 115);
            this.txtdiencudn.Name = "txtdiencudn";
            this.txtdiencudn.Size = new System.Drawing.Size(166, 22);
            this.txtdiencudn.TabIndex = 7;
            // 
            // txtmaphongdn
            // 
            this.txtmaphongdn.Location = new System.Drawing.Point(189, 53);
            this.txtmaphongdn.Name = "txtmaphongdn";
            this.txtmaphongdn.Size = new System.Drawing.Size(166, 22);
            this.txtmaphongdn.TabIndex = 6;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(41, 183);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(116, 16);
            this.label41.TabIndex = 5;
            this.label41.Text = "Chỉ số nước cũ :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(44, 118);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(113, 16);
            this.label40.TabIndex = 4;
            this.label40.Text = "Chỉ số điện cũ :";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(73, 58);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 16);
            this.label32.TabIndex = 3;
            this.label32.Text = "Mã phòng :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label31.Location = new System.Drawing.Point(358, 20);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(271, 20);
            this.label31.TabIndex = 2;
            this.label31.Text = "NHẬP ĐIỆN NƯỚC CHO PHÒNG";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.AutoSize = true;
            this.groupBox7.Controls.Add(this.btnlamlaidn);
            this.groupBox7.Controls.Add(this.btnhienthidn);
            this.groupBox7.Controls.Add(this.btnxoadn);
            this.groupBox7.Controls.Add(this.btnsuadn);
            this.groupBox7.Controls.Add(this.btnluudn);
            this.groupBox7.Location = new System.Drawing.Point(12, 257);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1000, 102);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Thao tác";
            // 
            // btnlamlaidn
            // 
            this.btnlamlaidn.Image = ((System.Drawing.Image)(resources.GetObject("btnlamlaidn.Image")));
            this.btnlamlaidn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlamlaidn.Location = new System.Drawing.Point(760, 20);
            this.btnlamlaidn.Name = "btnlamlaidn";
            this.btnlamlaidn.Size = new System.Drawing.Size(91, 35);
            this.btnlamlaidn.TabIndex = 21;
            this.btnlamlaidn.Text = "LÀM MỚI";
            this.btnlamlaidn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnlamlaidn.UseVisualStyleBackColor = true;
            this.btnlamlaidn.Click += new System.EventHandler(this.btnlamlaidn_Click);
            // 
            // btnhienthidn
            // 
            this.btnhienthidn.Image = ((System.Drawing.Image)(resources.GetObject("btnhienthidn.Image")));
            this.btnhienthidn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnhienthidn.Location = new System.Drawing.Point(551, 20);
            this.btnhienthidn.Name = "btnhienthidn";
            this.btnhienthidn.Size = new System.Drawing.Size(115, 35);
            this.btnhienthidn.TabIndex = 20;
            this.btnhienthidn.Text = "HIỂN THỊ";
            this.btnhienthidn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhienthidn.UseVisualStyleBackColor = true;
            this.btnhienthidn.Click += new System.EventHandler(this.btnhienthidn_Click_1);
            // 
            // btnxoadn
            // 
            this.btnxoadn.Image = ((System.Drawing.Image)(resources.GetObject("btnxoadn.Image")));
            this.btnxoadn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnxoadn.Location = new System.Drawing.Point(382, 20);
            this.btnxoadn.Name = "btnxoadn";
            this.btnxoadn.Size = new System.Drawing.Size(91, 35);
            this.btnxoadn.TabIndex = 19;
            this.btnxoadn.Text = "XÓA ";
            this.btnxoadn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoadn.UseVisualStyleBackColor = true;
            this.btnxoadn.Click += new System.EventHandler(this.btnxoadn_Click_1);
            // 
            // btnsuadn
            // 
            this.btnsuadn.Image = ((System.Drawing.Image)(resources.GetObject("btnsuadn.Image")));
            this.btnsuadn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsuadn.Location = new System.Drawing.Point(204, 19);
            this.btnsuadn.Name = "btnsuadn";
            this.btnsuadn.Size = new System.Drawing.Size(88, 36);
            this.btnsuadn.TabIndex = 18;
            this.btnsuadn.Text = "SỬA";
            this.btnsuadn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuadn.UseVisualStyleBackColor = true;
            this.btnsuadn.Click += new System.EventHandler(this.btnsuadn_Click_1);
            // 
            // btnluudn
            // 
            this.btnluudn.Image = ((System.Drawing.Image)(resources.GetObject("btnluudn.Image")));
            this.btnluudn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnluudn.Location = new System.Drawing.Point(50, 19);
            this.btnluudn.Name = "btnluudn";
            this.btnluudn.Size = new System.Drawing.Size(79, 36);
            this.btnluudn.TabIndex = 17;
            this.btnluudn.Text = "LƯU";
            this.btnluudn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnluudn.UseVisualStyleBackColor = true;
            this.btnluudn.Click += new System.EventHandler(this.btnluudn_Click_1);
            // 
            // bangthongke
            // 
            this.bangthongke.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bangthongke.AutoSize = true;
            this.bangthongke.Controls.Add(this.groupBox12);
            this.bangthongke.Controls.Add(this.groupBox9);
            this.bangthongke.Location = new System.Drawing.Point(224, 45);
            this.bangthongke.Name = "bangthongke";
            this.bangthongke.Size = new System.Drawing.Size(1026, 549);
            this.bangthongke.TabIndex = 20;
            this.bangthongke.TabStop = false;
            this.bangthongke.Text = "Thống kê";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.txtthongkephong);
            this.groupBox12.Controls.Add(this.label34);
            this.groupBox12.Location = new System.Drawing.Point(565, 65);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(403, 63);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Thống kê phòng";
            // 
            // txtthongkephong
            // 
            this.txtthongkephong.Enabled = false;
            this.txtthongkephong.Location = new System.Drawing.Point(214, 27);
            this.txtthongkephong.Name = "txtthongkephong";
            this.txtthongkephong.Size = new System.Drawing.Size(183, 20);
            this.txtthongkephong.TabIndex = 2;
            this.txtthongkephong.TextChanged += new System.EventHandler(this.txtthongkephong_TextChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 32);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(199, 13);
            this.label34.TabIndex = 0;
            this.label34.Text = "Tổng số phòng hiện có của KTX :";
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.AutoSize = true;
            this.groupBox9.Controls.Add(this.txtthongkesinhvien);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Location = new System.Drawing.Point(64, 63);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(418, 66);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Thống kê sinh viên";
            // 
            // txtthongkesinhvien
            // 
            this.txtthongkesinhvien.Enabled = false;
            this.txtthongkesinhvien.Location = new System.Drawing.Point(207, 27);
            this.txtthongkesinhvien.Name = "txtthongkesinhvien";
            this.txtthongkesinhvien.Size = new System.Drawing.Size(183, 20);
            this.txtthongkesinhvien.TabIndex = 1;
            this.txtthongkesinhvien.TextChanged += new System.EventHandler(this.txtthongkesinhvien_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 32);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(195, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Tổng số sinh viên có trong KTX :";
            // 
            // inDanhSáchĐiệnNướcToolStripMenuItem
            // 
            this.inDanhSáchĐiệnNướcToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("inDanhSáchĐiệnNướcToolStripMenuItem.Image")));
            this.inDanhSáchĐiệnNướcToolStripMenuItem.Name = "inDanhSáchĐiệnNướcToolStripMenuItem";
            this.inDanhSáchĐiệnNướcToolStripMenuItem.Size = new System.Drawing.Size(213, 38);
            this.inDanhSáchĐiệnNướcToolStripMenuItem.Text = "In danh sách điện nước";
            this.inDanhSáchĐiệnNướcToolStripMenuItem.Click += new System.EventHandler(this.inDanhSáchĐiệnNướcToolStripMenuItem_Click);
            // 
            // Trangchu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1250, 589);
            this.Controls.Add(this.bangthongke);
            this.Controls.Add(this.bangdiennuoc);
            this.Controls.Add(this.bang1tk);
            this.Controls.Add(this.bang1sv);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.h1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Trangchu";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÝ KÍ TÚC XÁ SINH VIÊN TỈNH KHÁNH HÒA ";
            this.Load += new System.EventHandler(this.Trangchu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.bang1tk.ResumeLayout(false);
            this.bang1tk.PerformLayout();
            this.bang2tk.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hitnthimaphongtk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hienthimsvtk)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.h1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.bang1sv.ResumeLayout(false);
            this.bang1sv.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.bang2sv.ResumeLayout(false);
            this.bang2sv.PerformLayout();
            this.bang3sv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsv)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.bangdiennuoc.ResumeLayout(false);
            this.bangdiennuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewdiennuoc)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.bangthongke.ResumeLayout(false);
            this.bangthongke.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhSáchPhòngHiệnCóToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hồSơSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóaĐơnĐiệnNướcĐiệnNướcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tiềnĐiệnToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềKTXToolStripMenuItem;
        private System.Windows.Forms.PictureBox h1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtmaphong;
        private System.Windows.Forms.TextBox txtmakhu;
        private System.Windows.Forms.TextBox txttenphong;
        private System.Windows.Forms.TextBox txtsonguoihientai;
        private System.Windows.Forms.TextBox txtsonguoitoida;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnhienthi;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.CheckBox Pnam;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox bang1sv;
        private System.Windows.Forms.TextBox txthinh;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtnghenghiepsv;
        private System.Windows.Forms.TextBox txtmoiquanhesv;
        private System.Windows.Forms.TextBox txtsdtghsv;
        private System.Windows.Forms.TextBox txttenghsv;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.MaskedTextBox txtngaysinhsv;
        private System.Windows.Forms.TextBox txtmpsv;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox gtsv;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtquequansv;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtsdtsv;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtcmndsv;
        private System.Windows.Forms.TextBox txttensv;
        private System.Windows.Forms.TextBox txthosv;
        private System.Windows.Forms.TextBox txtmaktxsv;
        private System.Windows.Forms.TextBox txtmasvsv;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox bang2sv;
        private System.Windows.Forms.Button btnhienthisv;
        private System.Windows.Forms.Button btnsuasv;
        private System.Windows.Forms.Button btnxoasv;
        private System.Windows.Forms.Button btnthemsv;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox bang3sv;
        private System.Windows.Forms.DataGridView dataGridViewsv;
        private System.Windows.Forms.GroupBox bang1tk;
        private System.Windows.Forms.GroupBox bang2tk;
        private System.Windows.Forms.DataGridView hitnthimaphongtk;
        private System.Windows.Forms.DataGridView hienthimsvtk;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btnxoamptk;
        private System.Windows.Forms.Button btnmptk;
        private System.Windows.Forms.Button btnhthimptk;
        private System.Windows.Forms.TextBox txtmptk;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btnxoasvtk;
        private System.Windows.Forms.Button btnsvtk;
        private System.Windows.Forms.Button btnhthimsvtk;
        private System.Windows.Forms.TextBox txtmsvtk;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox bangdiennuoc;
        private System.Windows.Forms.DataGridView dataGridViewdiennuoc;
        private System.Windows.Forms.TextBox txtnuocmoidn;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtdienmoidn;
        private System.Windows.Forms.DateTimePicker dateTimediennuoc;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtnuoccudn;
        private System.Windows.Forms.TextBox txtdiencudn;
        private System.Windows.Forms.TextBox txtmaphongdn;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnlamlaidn;
        private System.Windows.Forms.Button btnhienthidn;
        private System.Windows.Forms.Button btnxoadn;
        private System.Windows.Forms.Button btnsuadn;
        private System.Windows.Forms.Button btnluudn;
        private System.Windows.Forms.GroupBox bangthongke;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox txtthongkephong;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtthongkesinhvien;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ToolStripMenuItem inDanhSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inDanhSáchĐiệnNướcToolStripMenuItem;

    }
}

