﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLKTX.Khu
{
    public class KhuDTO
    {
        public string MaKhu {get;set;}///dữ liệu mã khu trong bảng dữ liệu khu
        public string Tenkhu{get;set;}///dữ liệu tên khu trong bảng dữ liệu khu
     
    }
}
