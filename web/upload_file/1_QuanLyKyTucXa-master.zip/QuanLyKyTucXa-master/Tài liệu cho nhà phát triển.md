﻿## TÀI LIỆU CHO NHÀ PHÁT TRIỂN

**Với mục tiêu ban đầu đề ra**
 
Tạo được một phần mềm hỗ trợ việc quản lý ký túc xá
sinh viên Khánh Hòa.

**Mục tiêu phát triển**

<ul>
<li> Đưa phần mềm quản lý ký túc xá sinh viên Khánh Hòa ban đầu thành 1 phần mềm quản lý
ký túc xá chung</li>
<li>Có quy mô lớn hơn, có cấu trúc đa tầng</li>
<li>Phù hợp với mọi loại hình ký túc xá </li>
<li>Mang tính đa dạng dễ sử dụng</li>
<li>Bổ sung nhiều chức năng đầy đủ để phần mềm trở thành công cụ hỗ trợ hữu ích</li>
</ul>

**Link tham khảo**

Muốn phát triển phần mềm và xuất bản thành phiên bản mới, phải có giấy phép dự án
được thông qua. Liên hệ gmail: Ngomaubaodhcn1b@gmail.com để được phép phát triển và
xuất bản.

